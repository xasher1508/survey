<?php
/**
 * Smarty Internal Plugin Compile If
 * Compiles the {if} {else} {elseif} {/if} tags
 *
 * @package    Smarty
 * @subpackage Compiler
 * @author     Uwe Tews
 */

/**
 * Smarty Internal Plugin Compile If Class
 *
 * @package    Smarty
 * @subpackage Compiler
 */
class Smarty_Internal_Compile_If extends Smarty_Internal_CompileBase
{
    /**
     * Compiles code for the {if} tag
     *
     * @param array                                 $args      array with attributes from parser
     * @param \Smarty_Internal_TemplateCompilerBase $compiler  compiler object
     * @param array                                 $parameter array with compilation parameter
     *
     * @return string compiled code
     * @throws \SmartyCompilerException
     */
    public function compile($args, Smarty_Internal_TemplateCompilerBase $compiler, $parameter)
    {
        // check and get attributes
        $_attr = $this->getAttributes($compiler, $args);
        $this->openTag($compiler, 'if', array(1, $compiler->nocache));
        // must whole block be nocache ?
        $compiler->nocache = $compiler->nocache | $compiler->tag_nocache;

        if (!array_key_exists("if condition", $parameter)) {
            $compiler->trigger_template_error("missing if condition", null, true);
        }

        if (is_array($parameter['if condition'])) {
            if ($compiler->nocache) {
                $_nocache = ',true';
                // create nocache var to make it know for further compiling
                if (is_array($parameter['if condition']['var'])) {
                    $var = trim($parameter['if condition']['var']['var'], "'");
                } else {
                    $var = trim($parameter['if condition']['var'], "'");
                }
                if (isset($compiler->template->tpl_vars[$var])) {
                    $compiler->template->tpl_vars[$var]->nocache = true;
                } else {
                    $compiler->template->tpl_vars[$var] = new Smarty_Variable(null, true);
                }
            } else {
                $_nocache = '';
            }
            if (is_array($parameter['if condition']['var'])) {
                $_output = "<?php if (!isset(\$_smarty_tpl->tpl_vars[" . $parameter['if condition']['var']['var'] .
                    "]) || !is_array(\$_smarty_tpl->tpl_vars[" . $parameter['if condition']['var']['var'] .
                    "]->value)) \$_smarty_tpl->smarty->ext->_var->createLocalArrayVariable(\$_smarty_tpl, " . $parameter['if condition']['var']['var'] .
                    "$_nocache);\n";
                $_output .= "if (\$_smarty_tpl->tpl_vars[" . $parameter['if condition']['var']['var'] . "]->value" .
                    $parameter['if condition']['var']['smarty_internal_index'] . " = " .
                    $parameter['if condition']['value'] . ") {?>";
            } else {
                $_output = "<?php if (!isset(\$_smarty_tpl->tpl_vars[" . $parameter['if condition']['var'] .
                    "])) \$_smarty_tpl->tpl_vars[" . $parameter['if condition']['var'] .
                    "] = new Smarty_Variable(null{$_nocache});";
                $_output .= "if (\$_smarty_tpl->tpl_vars[" . $parameter['if condition']['var'] . "]->value = " .
                    $parameter['if condition']['value'] . ") {?>";
            }

            return $_output;
        } else {
            return "<?php if ({$parameter['if condition']}) {?>";
        }
    }
}

/**
 * Smarty Internal Plugin Compile Else Class
 *
 * @package    Smarty
 * @subpackage Compiler
 */
class Smarty_Internal_Compile_Else extends Smarty_Internal_CompileBase
{
    /**
     * Compiles code for the {else} tag
     *
     * @param array                                 $args      array with attributes from parser
     * @param \Smarty_Internal_TemplateCompilerBase $compiler  compiler object
     * @param array                                 $parameter array with compilation parameter
     *
     * @return string compiled code
     */
    public function compile($args, Smarty_Internal_TemplateCompilerBase $compiler, $parameter)
    {
        list($nesting, $compiler->tag_nocache) = $this->closeTag($compiler, array('if', 'elseif'));
        $this->openTag($compiler, 'else', array($nesting, $compiler->tag_nocache));

        return "<?php } else { ?>";
    }
}

/**
 * Smarty Internal Plugin Compile ElseIf Class
 *
 * @package    Smarty
 * @subpackage Compiler
 */
class Smarty_Internal_Compile_Elseif extends Smarty_Internal_CompileBase
{
    /**
     * Compiles code for the {elseif} tag
     *
     * @param array                                 $args      array with attributes from parser
     * @param \Smarty_Internal_TemplateCompilerBase $compiler  compiler object
     * @param array                                 $parameter array with compilation parameter
     *
     * @return string compiled code
     * @throws \SmartyCompilerException
     */
    public function compile($args, Smarty_Internal_TemplateCompilerBase $compiler, $parameter)
    {
        // check and get attributes
        $_attr = $this->getAttributes($compiler, $args);

        list($nesting, $compiler->tag_nocache) = $this->closeTag($compiler, array('if', 'elseif'));

        if (!array_key_exists("if condition", $parameter)) {
            $compiler->trigger_template_error("missing elseif condition", null, true);
        }

        if (is_array($parameter['if condition'])) {
            $condition_by_assign = true;
            if ($compiler->nocache) {
                $_nocache = ',true';
                // create nocache var to make it know for further compiling
                if (is_array($parameter['if condition']['var'])) {
                    $var = trim($parameter['if condition']['var']['var'], "'");
                } else {
                    $var = trim($parameter['if condition']['var'], "'");
                }
                if (isset($compiler->template->tpl_vars[$var])) {
                    $compiler->template->tpl_vars[$var]->nocache = true;
                } else {
                    $compiler->template->tpl_vars[$var] = new Smarty_Variable(null, true);
                }
            } else {
                $_nocache = '';
            }
        } else {
            $condition_by_assign = false;
        }

        if (empty($compiler->prefix_code)) {
            if ($condition_by_assign) {
                $this->openTag($compiler, 'elseif', array($nesting + 1, $compiler->tag_nocache));
                if (is_array($parameter['if condition']['var'])) {
                    $_output = "<?php } else { if (!isset(\$_smarty_tpl->tpl_vars[" .
                        $parameter['if condition']['var']['var'] . "]) || !is_array(\$_smarty_tpl->tpl_vars[" .
                        $parameter['if condition']['var']['var'] .
                        "]->value)) \$_smarty_tpl->smarty->ext->_var->createLocalArrayVariable(\$_smarty_tpl, " .
                        $parameter['if condition']['var']['var'] . "$_nocache);\n";
                    $_output .= "if (\$_smarty_tpl->tpl_vars[" . $parameter['if condition']['var']['var'] . "]->value" .
                        $parameter['if condition']['var']['smarty_internal_index'] . " = " .
                        $parameter['if condition']['value'] . ") {?>";
                } else {
                    $_output = "<?php  } else { if (!isset(\$_smarty_tpl->tpl_vars[" .
                        $parameter['if condition']['var'] . "])) \$_smarty_tpl->tpl_vars[" .
                        $parameter['if condition']['var'] . "] = new Smarty_Variable(null{$_nocache});";
                    $_output .= "if (\$_smarty_tpl->tpl_vars[" . $parameter['if condition']['var'] . "]->value = " .
                        $parameter['if condition']['value'] . ") {?>";
                }

                return $_output;
            } else {
                $this->openTag($compiler, 'elseif', array($nesting, $compiler->tag_nocache));

                return "<?php } elseif ({$parameter['if condition']}) {?>";
            }
        } else {
            $tmp = '';
            foreach ($compiler->prefix_code as $code) {
                $tmp = $compiler->appendCode($tmp, $code);
            }
            $compiler->prefix_code = array();
            $tmp = $compiler->appendCode("<?php } else {?>", $tmp);
            $this->openTag($compiler, 'elseif', array($nesting + 1, $compiler->tag_nocache));
            if ($condition_by_assign) {
                if (is_array($parameter['if condition']['var'])) {
                    $_output = $compiler->appendCode($tmp, "<?php  if (!isset(\$_smarty_tpl->tpl_vars[" .
                                                         $parameter['if condition']['var']['var'] .
                                                         "]) || !is_array(\$_smarty_tpl->tpl_vars[" .
                                                         $parameter['if condition']['var']['var'] .
                                                         "]->value)) \$_smarty_tpl->smarty->ext->_var->createLocalArrayVariable(\$_smarty_tpl, " .
                                                         $parameter['if condition']['var']['var'] . "$_nocache);\n");
                    $_output .= "if (\$_smarty_tpl->tpl_vars[" . $parameter['if condition']['var']['var'] . "]->value" .
                        $parameter['if condition']['var']['smarty_internal_index'] . " = " .
                        $parameter['if condition']['value'] . ") {?>";
                } else {
                    $_output = $compiler->appendCode($tmp, "<?php if (!isset(\$_smarty_tpl->tpl_vars[" .
                                                         $parameter['if condition']['var'] .
                                                         "])) \$_smarty_tpl->tpl_vars[" .
                                                         $parameter['if condition']['var'] .
                                                         "] = new Smarty_Variable(null{$_nocache});");
                    $_output .= "if (\$_smarty_tpl->tpl_vars[" . $parameter['if condition']['var'] . "]->value = " .
                        $parameter['if condition']['value'] . ") {?>";
                }

                return $_output;
            } else {
                return $compiler->appendCode($tmp, "<?php if ({$parameter['if condition']}) {?>");
            }
        }
    }
}

/**
 * Smarty Internal Plugin Compile Ifclose Class
 *
 * @package    Smarty
 * @subpackage Compiler
 */
class Smarty_Internal_Compile_Ifclose extends Smarty_Internal_CompileBase
{
    /**
     * Compiles code for the {/if} tag
     *
     * @param array                                 $args      array with attributes from parser
     * @param \Smarty_Internal_TemplateCompilerBase $compiler  compiler object
     * @param array                                 $parameter array with compilation parameter
     *
     * @return string compiled code
     */
    public function compile($args, Smarty_Internal_TemplateCompilerBase $compiler, $parameter)
    {
        // must endblock be nocache?
        if ($compiler->nocache) {
            $compiler->tag_nocache = true;
        }
        list($nesting, $compiler->nocache) = $this->closeTag($compiler, array('if', 'else', 'elseif'));
        $tmp = '';
        for ($i = 0; $i < $nesting; $i ++) {
            $tmp .= '}';
        }

        return "<?php {$tmp}?>";
    }
}
