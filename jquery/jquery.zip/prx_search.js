$(document).ready(function()
{
	$('#search').keyup(function()
	{

		if($(this).val().length >= 3 || $(this).val() == '%')
		{
			$.get("../admin/prx_search.php", {search: $(this).val()}, function(data)
			{
				$("#results").html(data);
			});
		}
	});

    $("#btnSubmit").click(function(){
			$.get("../admin/prx_search.php", {search: '%'}, function(data)
			{
				$("#results").html(data);
			});
    });
});
